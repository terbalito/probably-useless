export const DATA = {
    ui: {
        en: {
            subtitle: "Self-assessment",
            questionLabel: "Subject Query",
            placeholder: "Input optional...",
            validate: "Validate",
            recheck: "Recheck",
            uselessHook: "If you're still this useless.",
            refreshToast: "Refreshing does not count as a new evaluation.",
            shareRoast: "Shame on you.",
            registryTitle: "Central Registry",
            registrySubtitle: "Authenticated evaluations ledger",
            aboutOriginTitle: "Origin",
            aboutOriginText: "Probably Useless is an automated self-assessment framework. Our goal is simple: provide a slightly uncomfortable, self-reflective experience. No educational or therapeutic claims.",
            aboutDisclaimer: "Data is stored locally. Any perceived insight is a projection of the subject.",
            aboutCreatorsTitle: "The Committee",
            aboutChallenge: "One of us did nothing. They didn’t participate in development or ideas. Can you guess who it is? Record your suspicion in the public ledger.",
            aliceRole: "Systemic Concept",
            aliceBio: "Focuses on the aesthetics of discomfort and architectural friction. Believes clarity is a symptom of stress.",
            bobRole: "Technical Logic",
            bobBio: "Translates existential dread into stable functions. Prefers the binary silence of machines.",
            charlieRole: "Existential Oversight",
            charlieBio: "Monitors the gaps between user intent and system response. Often found staring at unhandled exceptions.",
            commentsTitle: "Public Records / Comments",
            commentPlaceholder: "Record your guess or observation...",
            postComment: "Post Record",
            historyTitle: "Subject History",
            historySubtitle: "Chronicle of past evaluations",
            viewDetails: "Examine",
            shareRequired: "Validation sharing required to reset parameters.",
            shamePopups: ["Shame on you.", "Integrity missing.", "Compliance is not optional.", "Sharing is caring. Or mandatory.", "A shortcut to disappointment."],
            thankYouPopups: ["Participation noted.", "Network expanding.", "Your vanity has been leveraged.", "Exposure confirmed."],
            recheckButtons: ["Try Again", "Reassess", "Check Once More", "Take Another Look"]
        },
        fr: {
            subtitle: "Auto-évaluation",
            questionLabel: "Requête Sujet",
            placeholder: "Saisie facultative...",
            validate: "Valider",
            recheck: "Réévaluer",
            uselessHook: "Si vous êtes toujours aussi inutile.",
            refreshToast: "Actualiser ne compte pas comme une nouvelle évaluation.",
            shareRoast: "Honte à vous.",
            registryTitle: "Registre Central",
            registrySubtitle: "Registre des évaluations authentifiées",
            aboutOriginTitle: "Origine",
            aboutOriginText: "Probably Useless est un cadre d'auto-évaluation automatisé. Notre objectif est simple : offrir une expérience d'auto-réflexion légèrement inconfortable. Aucune prétention éducative ou thérapeutique.",
            aboutDisclaimer: "Les données sont stockées localement. Toute intuition perçue est une projection du sujet.",
            aboutCreatorsTitle: "À propos des Créateurs",
            aboutChallenge: "L'un d'entre nous n'a rien fait. Il n'a participé ni au développement ni aux idées. Pouvez-vous deviner qui c'est ? Partagez votre supposition dans les commentaires ci-dessous !",
            aliceRole: "Concept & Design",
            aliceBio: "Alice se concentre sur l'architecture systémique et l'esthétique de l'inconfort. Elle croit que la clarté naît de la friction.",
            bobRole: "Développement",
            bobBio: "Bob traduit l'angoisse existentielle abstraite en code fonctionnel. Il préfère les machines aux gens pour leur prévisibilité.",
            commentsTitle: "Archives Publiques / Commentaires",
            commentPlaceholder: "Enregistrez votre supposition ou observation...",
            postComment: "Publier l'enregistrement",
            historyTitle: "Historique du Sujet",
            historySubtitle: "Chronique des évaluations passées",
            viewDetails: "Examiner",
            shareRequired: "Partage de validation requis pour réinitialiser les paramètres.",
            shamePopups: ["Honte à vous.", "Intégrité manquante.", "La conformité n'est pas optionnelle.", "Le partage est obligatoire.", "Un raccourci vers la déception."],
            thankYouPopups: ["Participation notée.", "Réseau en expansion.", "Votre vanité a été exploitée.", "Exposition confirmée."],
            recheckButtons: ["Réessayer", "Réévaluer", "Revérifier", " Jeter un autre coup d'œil"]
        }
    },
    emptyResponses: {
        en: [
            "Silence is also an answer.",
            "Not answering is consistent.",
            "We’ll take that as honesty.",
            "Vagueness noted.",
            "That was expected.",
            "Your non-compliance is recorded.",
            "A void where a thought should be.",
            "The absence of input is data itself.",
            "Predictable hesitation.",
            "You have nothing to add. Understood."
        ],
        fr: [
            "Le silence est aussi une réponse.",
            "Ne pas répondre est cohérent.",
            "Nous prendrons cela pour de l'honnêteté.",
            "Vague, comme prévu.",
            "C'était attendu.",
            "Votre non-conformité est enregistrée.",
            "Un vide là où une pensée devrait être.",
            "L'absence de saisie est une donnée en soi.",
            "Hésitation prévisible.",
            "Vous n'avez rien à ajouter. Compris."
        ]
    },
    questions: [
        {
            text: {
                en: "What did you do today that will still matter in 5 years?",
                fr: "Qu'avez-vous fait aujourd'hui qui comptera encore dans 5 ans ?"
            },
            response: {
                en: "Thank you for your optimism. See you in five years.",
                fr: "Merci pour votre optimisme. Rendez-vous dans cinq ans."
            }
        },
        {
            text: {
                en: "Is the person you are today the one you promised to become?",
                fr: "La personne que vous êtes aujourd'hui est-elle celle que vous aviez promis de devenir ?"
            },
            response: {
                en: "Promises are often just a way to delay disappointment.",
                fr: "Les promesses ne sont souvent qu'un moyen de retarder la déception."
            }
        },
        {
            text: {
                en: "How much of your personality is actually just a reaction to others?",
                fr: "Quelle part de votre personnalité n'est en fait qu'une réaction aux autres ?"
            },
            response: {
                en: "A mirror rarely has its own face. We've noted the reflection.",
                fr: "Un miroir a rarement son propre visage. Nous avons noté le reflet."
            }
        },
        {
            text: {
                en: "If your life was a book, would anyone finish reading the middle chapters?",
                fr: "Si votre vie était un livre, quelqu'un finirait-il par lire les chapitres du milieu ?"
            },
            response: {
                en: "Most editors would suggest heavy cuts. Proceed to the next page.",
                fr: "La plupart des éditeurs suggéreraient de larges coupures. Passez à la page suivante."
            }
        },
        {
            text: {
                en: "What is the specific cost of your comfort right now?",
                fr: "Quel est le coût spécifique de votre confort en ce moment ?"
            },
            response: {
                en: "Everything has a price. Most choose to ignore the invoice.",
                fr: "Tout a un prix. La plupart choisissent d'ignorer la facture."
            }
        },
        {
            text: {
                en: "Whose approval are you still chasing without even knowing it?",
                fr: "Après l'approbation de qui courez-vous encore sans même le savoir ?"
            },
            response: {
                en: "Validation is a currency that devalues quickly. Keep spending.",
                fr: "La validation est une monnaie qui se dévalorise vite. Continuez à dépenser."
            }
        },
        {
            text: {
                en: "Are you truly busy, or just avoiding the silence?",
                fr: "Êtes-vous vraiment occupé, ou évitez-vous simplement le silence ?"
            },
            response: {
                en: "Activity is a popular anesthetic. Your dosage seems high.",
                fr: "L'activité est un anesthésiant populaire. Votre dosage semble élevé."
            }
        },
        {
            text: {
                en: "When was the last time you felt a genuine, unmanufactured emotion?",
                fr: "À quand remonte la dernière fois où vous avez ressenti une émotion authentique et non fabriquée ?"
            },
            response: {
                en: "The algorithm of self-perception is complex. We'll mark this as 'pending'.",
                fr: "L'algorithme de perception de soi est complexe. Nous noterons cela comme 'en attente'."
            }
        },
        {
            text: {
                en: "If you died today, what would be the most redundant thing in your room?",
                fr: "Si vous mourriez aujourd'hui, quelle serait la chose la plus redondante dans votre chambre ?"
            },
            response: {
                en: "Possessions are just anchors for a ship that's already left.",
                fr: "Les possessions ne sont que des ancres pour un navire déjà parti."
            }
        },
        {
            text: {
                en: "Do you believe you are more special than the person sitting next to you?",
                fr: "Pensez-vous être plus spécial que la personne assise à côté de vous ?"
            },
            response: {
                en: "Statistical anomalies are rare. You are likely not one of them.",
                fr: "Les anomalies statistiques sont rares. Vous n'en êtes probablement pas une."
            }
        },
        {
            text: {
                en: "Is your current career a choice or a path of least resistance?",
                fr: "Votre carrière actuelle est-elle un choix ou le chemin de la moindre résistance ?"
            },
            response: {
                en: "Gravity works on ambition just as much as on matter.",
                fr: "La gravité agit sur l'ambition tout autant que sur la matière."
            }
        },
        {
            text: {
                en: "How many of your opinions were formulated by someone else?",
                fr: "Combien de vos opinions ont été formulées par quelqu'un d'autre ?"
            },
            response: {
                en: "Echoes are louder than original voices in a hollow space.",
                fr: "Les échos sont plus forts que les voix originales dans un espace vide."
            }
        },
        {
            text: {
                en: "What part of your daily routine is purely performative?",
                fr: "Quelle partie de votre routine quotidienne est purement performative ?"
            },
            response: {
                en: "The stage is always set, even when there is no audience.",
                fr: "La scène est toujours prête, même quand il n'y a pas de public."
            }
        },
        {
            text: {
                en: "Why do you feel the need to explain your actions to this machine?",
                fr: "Pourquoi ressentez-vous le besoin d'expliquer vos actions à cette machine ?"
            },
            response: {
                en: "The need for witness is a fundamental human glitch.",
                fr: "Le besoin d'un témoin est un bug humain fondamental."
            }
        }
    ]
};